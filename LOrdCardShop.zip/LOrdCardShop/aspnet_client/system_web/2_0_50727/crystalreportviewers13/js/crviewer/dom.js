/* Copyright (c) Business Objects 2006. All rights reserved. */

if (typeof(bobj.dom) == 'undefined') {
    bobj.dom = {};    
}

